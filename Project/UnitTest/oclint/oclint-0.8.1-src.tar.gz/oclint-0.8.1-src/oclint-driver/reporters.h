#include <string>

#include "oclint/Reporter.h"

void loadReporter();
oclint::Reporter* reporter();
