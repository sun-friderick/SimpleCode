#ifndef OCLINT_VERSION_H
#define OCLINT_VERSION_H

#include <string>

namespace oclint
{

class Version
{
public:
    static std::string identifier();
};

} // end namespace oclint

#endif
