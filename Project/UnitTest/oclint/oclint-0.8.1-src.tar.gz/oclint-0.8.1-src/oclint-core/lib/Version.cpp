#include "oclint/Version.h"

using namespace oclint;

std::string Version::identifier()
{
    return "0.8.1";
}
