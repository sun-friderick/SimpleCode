Vim configure for developers.

Usage
=====

1. Clone repository

	```bash
	git clone https://github.com/ericzhang-cn/vim-conf.git
	```

2. Initialize vundle

	```bash
	cd vim-conf
	./init.sh
	```

3. Open vim and execute ":BundleInstall" command
